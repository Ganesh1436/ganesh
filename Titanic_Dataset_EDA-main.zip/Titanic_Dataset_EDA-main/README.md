# Titanic_Dataset_EDA

Titanic:
Requirements: python3,Libraries,Modules.
Libraries used for Preprocessing: Pyforest,Numpy,Pandas.
Libraries used for Data Visulation: Matplotlib,Seaborn.

This data set consists of information about the passengers of the RMS Titanic ship And also have info about is that particular passenger has survived that disaster or not. For every individual person, we have information about

Passenger Id- Id number of passengers in the data set

Name- Name of the passenger

Survival- Person survived or not ( 0 for No & 1 for Yes)

P-class- With what class of ticket that passenger was traveling.

sex- Male Or Female

Age- Age of the person in Years

Sibsp- Number of siblings/spouses on the Titanic

parch- Number of parents/children on the Titanic

Ticket- Ticket number

Fare- Amount of money that person paid to travel

Cabin- Cabin Number of Passenger

Embarked- Port of Embarkation ( C = Cherbourg, Q = Queenstown, S = Southampton)

