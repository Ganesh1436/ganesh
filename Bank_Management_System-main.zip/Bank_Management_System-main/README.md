# Bank_Management_System

Requirements: Python3.

Project description: Banking System project is a simple project developed using Python. The project contains only the admin side. The admin side manages all the basic functions which include creating a new account, withdraws and deposit amount, balance inquiries, and so on. In this mini-project, there is no such login system. This means he/she can use all those available features easily without any restriction. It is too easy to use, the user can check the total bank account record.
